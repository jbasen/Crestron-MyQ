﻿using System;
using System.Text;
using Crestron.SimplSharp;                          				// For Basic SIMPL# Classes
using Crestron.SimplSharp.Net.Https;

namespace MyQ
{
	#region Enum
	enum Debug_Options
	{
		None,								//Don't do anything with debug information
		Console,							//Output debug information to the console
		Error_Log,							//Send debug information to the error log
		Both								//Send debug infomation to both the console and error log
	};
	#endregion

	public class MyQ_Integration
	{
		#region Callback Delegates
		public delegate void DelegateFn1(SimplSharpString Name_1, SimplSharpString Name_2, SimplSharpString Name_3, SimplSharpString Name_4,
			SimplSharpString Serial_Number_1, SimplSharpString Serial_Number_2, SimplSharpString Serial_Number_3, SimplSharpString Serial_Number_4);
		public DelegateFn1 callback_fn1 { set; get; }
		#endregion

		#region Declarations
		private static Debug_Options Debug;
		private const int Door_Count = 4;	//number of doors supported by module
		private const string Base_Url_LiftMaster = "https://api.myqdevice.com/api/v5";
		private const string Base_Url_LiftMaster_Device = "https://api.myqdevice.com/api/v5.1";
		private const string Auth_Url = "/Login";
		private const string Users_Url = "/My";
		private const string Devices_Url = "/Accounts/";

		private const string Application_ID = "JVM/G9Nwih5BwKgNCjLxiFUQxQijAebyyg8QUHr7JOrP+tuPb8iHfRHKwTmDzHOu";
		private string Username;
		private string Password;
		private string Security_Token = string.Empty;
		private string User_ID = string.Empty;
		private string[] Serial_Number = new string[Door_Count];
		private string[] Name = new string[Door_Count];
		private bool Initialized = false;
		#endregion

		//****************************************************************************************
		// 
		//  MyQ_Integration	-	Default Constructor
		// 
		//****************************************************************************************
		public MyQ_Integration()
		{
		}

		//****************************************************************************************
		// 
		//  Initialize	-	Module Initialization
		// 
		//****************************************************************************************
		public short Initialize(string Username, string Password, short Debug)
		{
			Debug_Message("Initialize", "Entry");
			//Debug_Message("Initialize", "Username = " + Username);
			//Debug_Message("Initialize", "Password = " + Password);

			//set that initialization was not successfully completed
			Initialized = false;

			Set_Debug_Message_Output(Debug);

			#region Save Parameters
			this.Username = Username;
			this.Password = Password;
			#endregion

			#region Login and Get Security Token
			if (Login(Username, Password) == false)
			{
				Debug_Message("Initialize", "Login Failed");
				return 0;
			}
			#endregion

			#region Get User ID
			if (Get_User_Info() == false)
			{
				Debug_Message("Initialize", "Get_User_Info Failed");
				return 0;
			}
			#endregion

			#region Get Device Names and Serial Numbers
			if (Get_System_Info() == false)
			{
				Debug_Message("Initialize", "Get_System_Info Failed");
				return 0;
			}
			#endregion

			#region Pass back strings to Simpl
			if (callback_fn1 != null)
			{
				callback_fn1(Name[0], Name[1], Name[2], Name[3], Serial_Number[0],
					Serial_Number[1], Serial_Number[2], Serial_Number[3]);
			}
			else
			{
				CrestronConsole.PrintLine("MyQ - Initialize - Invalid Callback");
				Crestron.SimplSharp.ErrorLog.Error("MyQ - Initialize - Invalid Callback");
				return 0;
			}
			#endregion

			//set that initialization was successfully completed
			Debug_Message("Initialize", "SUCCESS");

			Initialized = true;

			return 1;
		}

		//****************************************************************************************
		// 
		//  Set_Door_State	-	Open/Close a garage door
		// 
		//****************************************************************************************
		public void Set_Door_State(string Command, short Door_Index)
		{
			Debug_Message("Set_Door_State", "Entry");

			#region Make Sure Initialization Was Run
			if (Initialized == false)
			{
				return;
			}
			#endregion

			#region Login and Get Security Token
			if (Login(Username, Password) == false)
			{
				return;
			}
			#endregion

			#region Get User ID
			if (Get_User_Info() == false)
			{
				return;
			}
			#endregion

			#region Get Device Names and Serial Numbers
			if (Get_System_Info() == false)
			{
				return;
			}
			#endregion

			#region Create URL and Message Body
			string url = Base_Url_LiftMaster_Device + Devices_Url + User_ID + "/devices/" + Serial_Number[Door_Index] + "/actions";
			string body = "{\"action_type\":\"" + Command + "\"}";
			Debug_Message("Set_Door_State", "url = " + url);
			Debug_Message("Set_Door_State", "body = " + body);
			#endregion

			#region Make HTTPS Request
			try
			{
				HttpsClientResponse response = Https_Request(url, body, true, RequestType.Put);
				if (response != null)
				{
					Debug_Message("Set_Door_State", "response.ContentString = " + response.ContentString);
					return;
				}
			}
			catch (Exception ex)
			{
				CrestronConsole.PrintLine("MyQ - Set_Door_State - Error setting door state to " + Command);
				CrestronConsole.PrintLine(ex.ToString());
				Crestron.SimplSharp.ErrorLog.Error("MyQ - Set_Door_State - Error setting door state to " + Command);
				Crestron.SimplSharp.ErrorLog.Error(ex.ToString());
				return;
			}
			#endregion
		}
		
		//****************************************************************************************
		// 
		//  Login	-	Login to MyQ and get security token
		// 
		//****************************************************************************************
		private bool Login(string Username, string Password)
		{
			Debug_Message("Login", "Entry");

			#region Clear Data Elements
			Security_Token = string.Empty;
			User_ID = string.Empty;
			for (int i = 0; i < Door_Count; i++)
			{
				Serial_Number[i] = string.Empty;
				Name[i] = string.Empty;
			}
			#endregion

			#region Error Checking
			if (Username == "")
			{
				CrestronConsole.PrintLine("MyQ - Login - A Username is required for PushOvers Notification");
				Crestron.SimplSharp.ErrorLog.Error("MyQ - Login - A Username is required for PushOvers Notification");
				return false;
			}

			if (Password == "")
			{
				CrestronConsole.PrintLine("MyQ - Login - A Password is required for PushOvers Notification");
				Crestron.SimplSharp.ErrorLog.Error("MyQ - Login - A Password is required for PushOvers Notification");
				return false;
			}
			#endregion

			#region Create URL and Message Body
			string url = "https://api.myqdevice.com/api/v5/Login";
			string body = "{\"Username\":\"" + Username + "\",\"Password\":\"" + Password + "\"}";
			Debug_Message("Login", "url = " + url);
			//Debug_Message("Login", "body = " + body);
			#endregion

			#region Make HTTPS Request and parse returned json
			try
			{
				HttpsClientResponse response = Https_Request(url, body, false, RequestType.Post);
				if (response != null)
				{
					//Parse Security Token from returned json packet
					Security_Token = Parse_Data_Substring(response.ContentString, "", "SecurityToken\":\"", "\"");
					Debug_Message("Login", "Security_Token = " + Security_Token);
					return true;
				}
				else
				{
					Debug_Message("Login", "Login Failed");
					Security_Token = string.Empty;
					return false;
				}
			}
			catch (Exception ex)
			{
				CrestronConsole.PrintLine("MyQ - Login - Error Logging into MyQ - Username = " + Username + ", Password = " + Password);
				CrestronConsole.PrintLine(ex.ToString());
				Crestron.SimplSharp.ErrorLog.Error("MyQ - Login - Error Logging into MyQ - Username = " + Username + ", Password = " + Password);
				Crestron.SimplSharp.ErrorLog.Error(ex.ToString());
				return false;
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Get_User_Info	-	Retrive info for logged in user
		// 
		//****************************************************************************************
		private bool Get_User_Info()
		{
			Debug_Message("Get_User_Info", "Entry");

			#region Clear Data Elements
			User_ID = string.Empty;
			for (int i = 0; i < Door_Count; i++)
			{
				Serial_Number[i] = string.Empty;
			}
			#endregion

			#region Error Checking
			if (string.IsNullOrEmpty(Security_Token))
			{
				Debug_Message("Get_User_Info", "No Security Token - Can't Retrieve User Info");
				return false;
			}
			#endregion

			#region Create URL
			string parameters = "?securityToken=" + Security_Token + "&expand=account";
			string url = Base_Url_LiftMaster + Users_Url + parameters;
			Debug_Message("Get_User_Info", "url = " + url);
			#endregion

			#region Make HTTPS Request and parse returned json
			try
			{
				HttpsClientResponse response = Https_Request(url, "", false, RequestType.Get);
				if (response != null)
				{
					//Parse User ID from returned json packet
					User_ID = Parse_Data_Substring(response.ContentString, "", "Id\":\"", "\"");
					Debug_Message("Get_User_Info", "User_ID = " + User_ID);
					return true;
				}
				else
				{
					Debug_Message("Get_User_Info", "Get User Info Failed");
					User_ID = string.Empty;
					return false;
				}
			}
			catch (Exception ex)
			{
				CrestronConsole.PrintLine("MyQ - Get_User_Info - Error Retreiving User_ID");
				CrestronConsole.PrintLine(ex.ToString());
				Crestron.SimplSharp.ErrorLog.Error("MyQ - Get_User_Info - Error Retreiving User_ID");
				Crestron.SimplSharp.ErrorLog.Error(ex.ToString());
				return false;
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Get_System_Info	-	Retrieve System Info from MyQ
		// 
		//****************************************************************************************
		private bool Get_System_Info()
		{
			Debug_Message("Get_System_Info", "Entry");

			#region Clear Data Elements
			for (int i = 0; i < Door_Count; i++)
			{
				Serial_Number[i] = string.Empty;
				Name[i] = string.Empty;
			}
			#endregion

			#region Error Checking
			if ((string.IsNullOrEmpty(Security_Token)) || (string.IsNullOrEmpty(User_ID)))
			{
				return false;
			}
			#endregion

			#region Create URL
			string parameters = "?securityToken=" + Security_Token;
			string url = Base_Url_LiftMaster_Device + Devices_Url + User_ID + "/Devices" + parameters;
			Debug_Message("Get_System_Info", "url = " + url);
			#endregion

			#region Make HTTPS Request and parse returned json
			try
			{
				HttpsClientResponse response = Https_Request(url, "", false, RequestType.Get);
				if (response != null)
				{
					//Parse Serial Numbers and names of door openers from returned json packet
					int Device_Index = 0;
					string s = response.ContentString;
					int Device_Count = int.Parse(Parse_Data_Substring(s, "", "\"count\":", ","));
					Debug_Message("Get_System_Info", "Device_Count = " + Device_Count);
					int Start_Index = s.IndexOf("\"items\":[", 0);
					int End_Index = 0;
					for (int i = 1; i <= Device_Count; i++)
					{
						End_Index = s.IndexOf("}}", Start_Index);
						string Section = s.Substring(Start_Index, End_Index - Start_Index);
						string Name = Parse_Data_Substring(Section, "", "\"name\":\"", "\"");
						string Type = Parse_Data_Substring(Section, "", "\"device_type\":\"", "\"");
						string Serial_Number = Parse_Data_Substring(Section, "", "\"serial_number\":\"", "\"");
						Debug_Message("Get_System_Info", "Name = " + Name);
						Debug_Message("Get_System_Info", "Type = " + Type);
						Debug_Message("Get_System_Info", "Serial_Number = " + Serial_Number);
						//if this device is an opener then save the info
						if (Type == "wifigaragedooropener")
						{
							this.Serial_Number[Device_Index] = Serial_Number;
							this.Name[Device_Index] = Name;
							Device_Index++;
						}
						Start_Index = End_Index + 2;
					}
					return true;
				}
				else
				{
					//Make Sure Data Elements Cleared on error retreiving data
					Debug_Message("Get_System_Info", "Get System Info Failed");
					for (int i = 0; i < Door_Count; i++)
					{
						Serial_Number[i] = string.Empty;
						Name[i] = string.Empty;
					}
					return false;
				}
			}
			catch (Exception ex)
			{
				CrestronConsole.PrintLine("MyQ - Get_System_Info - Error Retreiving Door Serial Numbers and Names");
				CrestronConsole.PrintLine(ex.ToString());
				Crestron.SimplSharp.ErrorLog.Error("MyQ - Get_System_Info - Error Retreiving Door Serial Numbers and Names");
				Crestron.SimplSharp.ErrorLog.Error(ex.ToString());
				return false;
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Https_Request	-	Perform Https Request
		// 
		//****************************************************************************************
		private HttpsClientResponse Https_Request(string url, string body, bool include_security_token, RequestType Type)
		{
			try
			{
				Debug_Message("Https_Request", "Entry");
				//Debug_Message("Https_Request", "url = " + url);
				//Debug_Message("Https_Request", "body = " + body);

				#region Create Client and Set Options
				HttpsClient httpsClient = new HttpsClient();
				httpsClient.KeepAlive = false;
				httpsClient.Accept = "application/json";
				//turn verification off, to stop it taking a dump on cert errors
				httpsClient.HostVerification = false;
				httpsClient.PeerVerification = false;
				httpsClient.Verbose = true;//TESTER
				#endregion

				#region Create Request and Populate It
				HttpsClientRequest request = new HttpsClientRequest();
				request.RequestType = Type;
				request.Header.ContentType = "application/json";
				request.Header.SetHeaderValue("MyQApplicationId", Application_ID);
				request.Header.SetHeaderValue("Accept", "*/*");
				request.Header.SetHeaderValue("Transfer-Encoding", "");
				request.Header.SetHeaderValue("Expect", "");
				request.Header.SetHeaderValue("ApiVersion", "5");//Tester
				request.Header.SetHeaderValue("User-Agent", "myQ/19569 CFNetwork/1107.1 Darwin/19.0.0");//Tester
				request.Header.SetHeaderValue("BrandId", "2");//Tester
				request.Header.SetHeaderValue("Culture", "en");//Tester
				if (include_security_token)
				{
					request.Header.SetHeaderValue("SecurityToken", Security_Token);
				}
				if (!string.IsNullOrEmpty(body))
				{
					request.ContentString = body;
					request.Header.SetHeaderValue("Content-Length", Convert.ToString(body.Length));
				}
				request.Url.Parse(url);
				#endregion

				#region Dispatch Request and Get Response
				HttpsClientResponse response;
				response = httpsClient.Dispatch(request);
				#endregion

				#region Manage Response
				if ((response.Code < 200) || (response.Code >= 300))
				{
					// server threw a error
					Debug_Message("Https_Request", "Error - response.Code = " + response.Code);
					Debug_Message("Https_Request", "Error - response.ContentString = " + response.ContentString);
					return null;
				}
				else
				{
					//Success
					Debug_Message("Https_Request", "Success - response.Code = " + response.Code);
					Debug_Message("Https_Request", "Success - response.ContentString = " + response.ContentString);
					return response;
				}
				#endregion
			}
			catch (Exception ex)
			{
				CrestronConsole.PrintLine("Https_Request - " + ex.ToString());
				Crestron.SimplSharp.ErrorLog.Error("Https_Request - " + ex.ToString());
				return null;
			}
		}

		//****************************************************************************************
		// 
		//  Parse_Data_Substring	-	Parse Data Element from Json
		// 
		//****************************************************************************************
		private string Parse_Data_Substring(string s, string section, string id, string ending_char)
		{
			int index1, index2, section_index;

			//Reporting of not finding section or string as an error eliminted because 
			//there are too many situations where the code has to accomodate the fact
			//that hubitat will send back very different messages depending on exactly
			//what setting was changed on a device.  Thermostat is the prime example

			//if data element located within a specific section of json, go to that section
			if (section != "")
			{
				section_index = s.IndexOf(section, 0);
				if (section_index == -1)
				{
					//CrestronConsole.PrintLine("Hubitat-Parse_Data_Substring - Unable to Locate " + section + " in " + s);
					//Crestron.SimplSharp.ErrorLog.Error("Hubitat-Parse_Data_Substring - Unable to Locate " + section + " in " + s);
					return "";
				}
				else
				{
					section_index += section.Length;
				}
			}
			else
			{
				section_index = 0;
			}

			//get index to start of value
			index1 = s.IndexOf(id, section_index);
			if (index1 == -1)
			{
				//CrestronConsole.PrintLine("Hubitat-Parse_Data_Substring - Unable to Locate " + id + " in " + s);
				//Crestron.SimplSharp.ErrorLog.Error("Hubitat-Parse_Data_Substring - Unable to Locate " + id + " in " + s);
				return "";
			}
			else
			{
				index1 += id.Length;
			}

			//get index to end of value
			index2 = s.IndexOf(ending_char, (index1 + 1));
			if (index2 == -1)
			{
				CrestronConsole.PrintLine("Hubitat-Parse_Data_Substring - Unable to Locate terminating " + ending_char + " for " + id + " in " + s);
				Crestron.SimplSharp.ErrorLog.Error("Hubitat-Parse_Data_Substring - Unable to Locate terminating " + ending_char + " for " + id + " in " + s);
				return "";
			}

			//get value substring and pass it back
			return s.Substring(index1, index2 - index1);
		}

		//****************************************************************************************
		// 
		//  Set_Debug_Message_Output	-	Save whether debug messages will be output
		//									to console, error log, both, or not sent
		//									0 = None, 1 = Console, 2 = Error Log, 3 = Both
		// 
		//****************************************************************************************
		public void Set_Debug_Message_Output(short Debug)
		{
			//Save debug message setting as an enum
			switch (Debug)
			{
				case 0:
					MyQ_Integration.Debug = Debug_Options.None;
					break;

				case 1:
					MyQ_Integration.Debug = Debug_Options.Console;
					break;

				case 2:
					MyQ_Integration.Debug = Debug_Options.Error_Log;
					break;

				case 3:
					MyQ_Integration.Debug = Debug_Options.Both;
					break;
			}
		}

		//****************************************************************************************
		// 
		//  Debug_Message	-	Send Debug Message to Console or Error Log
		//						Depending on Selection
		// 
		//****************************************************************************************
		private static void Debug_Message(string Name, string s)
		{
			const int characters_per_line = 250;
			int start_index = 0;
			int length = characters_per_line;

			//json responses are too large for Simpl Debugger to display on a single line
			//so, we break them up into chunks of 250 characters to be printed on 1 line
			while (start_index < s.Length)
			{
				if ((start_index + characters_per_line) > s.Length)
				{
					length = s.Length - start_index;
				}

				string sub = s.Substring(start_index, length);

				if ((Debug == Debug_Options.Console) || (Debug == Debug_Options.Both))
				{
					CrestronConsole.PrintLine("MyQ - " + Name + " - " + sub);
				}

				if ((Debug == Debug_Options.Error_Log) || (Debug == Debug_Options.Both))
				{
					Crestron.SimplSharp.ErrorLog.Notice("MyQ - " + Name + " - " + sub + "\n");
				}

				start_index += characters_per_line;
			}
		}

	}
}
