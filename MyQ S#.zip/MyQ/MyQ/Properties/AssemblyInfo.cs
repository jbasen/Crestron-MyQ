﻿using System.Reflection;

[assembly: AssemblyTitle("MyQ")]
[assembly: AssemblyCompany("HP Inc.")]
[assembly: AssemblyProduct("MyQ")]
[assembly: AssemblyCopyright("Copyright © HP Inc. 2020")]
[assembly: AssemblyVersion("1.0.0.*")]

